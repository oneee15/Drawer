package com.johnalvinmariano.yugioh.ui.lists;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.johnalvinmariano.yugioh.R;
import com.johnalvinmariano.yugioh.databinding.FragmentListsBinding;


public class ListsFragment extends Fragment {

    private FragmentListsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
       ListsViewModel listsViewModel =
                new ViewModelProvider(this).get(ListsViewModel.class);

        binding = FragmentListsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        final RecyclerView recyclerView = root.findViewById(R.id.rvView);
        CustomAdapter customAdapter2 = new CustomAdapter(

                new String[]{"100-Year Awakening", "Absorb Spell", "Acorno", "Ashoka Pillar", "Amazon Fighter", "Ambulance Rescueroid", "Aetonyx Flame", "Ace of Sword", "Dark Magician", "Attachment Dragon", "Ancient Dragon"},
                new int[]{R.drawable.wke,R.drawable.abs,R.drawable.aco,R.drawable.buld,R.drawable.ama,R.drawable.am,R.drawable.aeto,R.drawable.ace,R.drawable.dark,R.drawable.drag,R.drawable.an},
                new String[]{getString(R.string.wake), getString(R.string.aba),
                        getString(R.string.ac),getString(R.string.pill),getString(R.string.ama),getString(R.string.bul),getString(R.string.aeto),getString(R.string.swo),getString(R.string.mag),getString(R.string.ata),getString(R.string.an)
                });


        recyclerView.setLayoutManager(new LinearLayoutManager(root.getContext()));
        recyclerView.setAdapter(customAdapter2);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

