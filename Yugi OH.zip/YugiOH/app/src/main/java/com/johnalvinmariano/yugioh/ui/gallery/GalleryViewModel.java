package com.johnalvinmariano.yugioh.ui.gallery;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class GalleryViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public GalleryViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("The Yu-Gi-Oh! Trading Card Game[a] is a collectible card game developed and published by Konami. It's based on the fictional game of Duel Monsters (also known as Magic & Wizards in the manga) created by manga artist Kazuki Takahashi, which appears in portions of the manga franchise Yu-Gi-Oh! and is the central plot device throughout its various anime adaptations and spinoff series.[2]\n" +
                "\n" +
                "The trading card game was launched by Konami in 1999 in Japan and March 2002 in North America.[3] It was named the top selling trading card game in the world by Guinness World Records on July 7, 2009, having sold over 22 billion cards worldwide.[4] As of March 31, 2011, Konami Digital Entertainment Co., Ltd. Japan sold 25.2 billion cards globally since 1999.[5] As of January 2021, the game is estimated to have sold about 35 billion cards worldwide.[6][7] Yu-Gi-Oh! Speed Duel, a faster and simplified version of the game, was launched worldwide in January 2019. Another faster-paced variation, Yu-Gi-Oh! Rush Duel, launched in Japan in April 2020.");
    }

    public LiveData<String> getText() {
        return mText;
    }
}