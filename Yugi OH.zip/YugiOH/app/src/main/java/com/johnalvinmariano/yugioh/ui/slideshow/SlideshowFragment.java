package com.johnalvinmariano.yugioh.ui.slideshow;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.johnalvinmariano.yugioh.R;
import com.johnalvinmariano.yugioh.databinding.FragmentSlideshowBinding;
import com.johnalvinmariano.yugioh.ui.data.CardModel;
import com.johnalvinmariano.yugioh.ui.data.DatabaseHelper;

import java.util.List;

public class SlideshowFragment extends Fragment {

    private FragmentSlideshowBinding binding;
    private CustomAdapter customAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        SlideshowViewModel slideshowViewModel =
                new ViewModelProvider(this).get(SlideshowViewModel.class);

        binding = FragmentSlideshowBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final RecyclerView recyclerView = root.findViewById(R.id.recyclerVIew);
        DatabaseHelper db = new DatabaseHelper(root.getContext());
        List<CardModel> data = db.getAllCards();
        customAdapter = new CustomAdapter(
                data,
                new CustomAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(CardModel item) {
                        Snackbar.make(root, item.cardName, Snackbar.LENGTH_LONG).show();
                    }
                }, new CustomAdapter.OnFaveClickListener() {
            @Override
            public void onItemClick(CardModel item, int position) {
                db.updateFavorite(item.cardId, item.favorite == 0 ? 1 : 0);
                data.set(position, new CardModel(item.cardId, item.cardName,item.description, item.itemSold, item.price, item.image, item.favorite == 0 ? 1 : 0));
                customAdapter.notifyDataSetChanged();
                Snackbar.make(root, item.cardName + " has been " + (item.favorite == 0 ? "added" : "removed") + " to your Favorites.", Snackbar.LENGTH_LONG).show();
            }
        },
                root.getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(root.getContext()));
        recyclerView.setAdapter(customAdapter);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}