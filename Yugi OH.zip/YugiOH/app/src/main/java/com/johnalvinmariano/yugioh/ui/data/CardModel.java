package com.johnalvinmariano.yugioh.ui.data;

import androidx.annotation.NonNull;

public class CardModel {
    public int cardId;
    public String cardName;
    public String description;
    public String itemSold;
    public String price;
    public String image;
    public int favorite;

    public CardModel(int cardId, String cardName, String description, String itemSold,
                     String price, String image, int favorite){
    this.cardId = cardId;
    this.cardName = cardName;
    this.description = description;
    this.itemSold = itemSold;
    this.price = price;
    this.image = image;
    this.favorite = favorite;
    }

    @NonNull
    @Override
    public String toString() {
        String s = "" + cardId + ": " + cardName;
        return s;
    }
}
