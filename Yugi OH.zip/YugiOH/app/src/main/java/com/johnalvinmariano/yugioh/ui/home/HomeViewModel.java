package com.johnalvinmariano.yugioh.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("\"Yu-Gi-Oh!\" cards are the heart of the popular trading card game inspired by the manga and anime series of the same name. These cards feature a vast array of monsters, spells, and traps, each with unique abilities and effects that players use to duel against each other. Here's a breakdown:\n" +
                "\n" +
                "Monster Cards: These cards represent creatures that players summon to battle their opponent's monsters or to directly attack their opponent's life points. Monster cards come in different types such as Normal, Effect, Fusion, Synchro, Xyz, Pendulum, Link, and more, each with its own gameplay mechanics.\n" +
                "\n" +
                "Spell Cards: Spell cards offer various effects that can assist a player's monsters, hinder the opponent's strategies, or alter the game state in some way. They can be activated during a player's turn to gain advantages or disrupt the opponent's plays.\n" +
                "\n" +
                "Trap Cards: Trap cards are set on the field and can be activated in response to specific conditions during either player's turn. They often have effects that can negate opponent's moves, protect your monsters, or hinder their strategies.\n" +
                "\n" +
                "Rarity Levels: Cards come in different rarities, indicating their value and scarcity. Common, Rare, Super Rare, Ultra Rare, Secret Rare, and more denote how difficult they are to obtain.\n" +
                "\n" +
                "Archetypes: Certain cards belong to specific groups or themes known as archetypes. These cards often work well together, synergizing their effects and strategies to create powerful combinations.\n" +
                "\n" +
                "The game involves strategy, deck building, and knowledge of card effects and interactions. Players construct their decks using a combination of monster, spell, and trap cards, aiming to defeat their opponent by reducing their life points to zero.");
    }

    public LiveData<String> getText() {
        return mText;
    }
}